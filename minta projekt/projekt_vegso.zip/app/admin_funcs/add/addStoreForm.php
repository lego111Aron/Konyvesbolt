<div class="container mt-5 mt-5">
    <h3>Áruház felvétele</h3>
    <form action="admin_funcs/add/addStore.php" method="post">
        <div class="form-group">
            <label for="address_input">Cím</label>
            <input type="text" class="form-control" name="address" id="address_input" style="max-width: 300px;">
        </div>

        <button type="submit" class="btn btn-success">Hozzáadás</button>
    </form>
</div>
